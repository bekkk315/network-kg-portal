export interface User {
  id: string;
  name: string;
  email: string;
  role: 'user' | 'admin';
  joinDate: string;
}

export interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
}

export interface QuizResult {
  id: string;
  userId: string;
  score: number;
  totalQuestions: number;
  completedAt: string;
}

export interface ForumTopic {
  id: string;
  title: string;
  content: string;
  author: string;
  authorId: string;
  createdAt: string;
  replies: ForumReply[];
}

export interface ForumReply {
  id: string;
  content: string;
  author: string;
  authorId: string;
  createdAt: string;
}

export interface NewsItem {
  id: string;
  title: string;
  summary: string;
  content: string;
  author: string;
  publishedAt: string;
  imageUrl?: string;
}

export interface Course {
  id: string;
  title: string;
  description: string;
  videoUrl: string;
  embedUrl?: string;
  duration: string;
  level: 'Beginner' | 'Intermediate' | 'Advanced';
  instructor: string;
}