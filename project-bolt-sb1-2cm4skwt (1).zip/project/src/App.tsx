import React, { useState } from 'react';
import { AuthProvider } from './contexts/AuthContext';
import Header from './components/Layout/Header';
import HomePage from './components/Pages/HomePage';
import DetailsPage from './components/Pages/DetailsPage';
import QuizPage from './components/Pages/QuizPage';
import NewsPage from './components/Pages/NewsPage';
import CoursesPage from './components/Pages/CoursesPage';
import ForumPage from './components/Pages/ForumPage';
import ProfilePage from './components/Pages/ProfilePage';
import LoginForm from './components/Auth/LoginForm';
import RegisterForm from './components/Auth/RegisterForm';

function App() {
  const [currentPage, setCurrentPage] = useState('home');

  const renderPage = () => {
    switch (currentPage) {
      case 'home':
        return <HomePage onNavigate={setCurrentPage} />;
      case 'details':
        return <DetailsPage onNavigate={setCurrentPage} />;
      case 'quiz':
        return <QuizPage onNavigate={setCurrentPage} />;
      case 'news':
        return <NewsPage onNavigate={setCurrentPage} />;
      case 'courses':
        return <CoursesPage onNavigate={setCurrentPage} />;
      case 'forum':
        return <ForumPage onNavigate={setCurrentPage} />;
      case 'profile':
        return <ProfilePage onNavigate={setCurrentPage} />;
      case 'login':
        return <LoginForm onNavigate={setCurrentPage} />;
      case 'register':
        return <RegisterForm onNavigate={setCurrentPage} />;
      default:
        return <HomePage onNavigate={setCurrentPage} />;
    }
  };

  return (
    <AuthProvider>
      <div className="min-h-screen bg-gray-50">
        {!['login', 'register'].includes(currentPage) && (
          <Header currentPage={currentPage} onNavigate={setCurrentPage} />
        )}
        {renderPage()}
      </div>
    </AuthProvider>
  );
}

export default App;