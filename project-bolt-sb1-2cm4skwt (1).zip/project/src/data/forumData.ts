import { ForumTopic } from '../types';

// Функция для получения даты несколько дней назад от 19 июня 2025
const getDateDaysAgo = (days: number) => {
  const baseDate = new Date('2025-06-19T12:00:00Z');
  baseDate.setDate(baseDate.getDate() - days);
  return baseDate.toISOString();
};

export const forumTopics: ForumTopic[] = [
  {
    id: '1',
    title: 'Лучшие практики настройки OSPF в корпоративных сетях',
    content: 'Коллеги, поделитесь опытом настройки OSPF в больших корпоративных сетях. Какие area лучше использовать? Как правильно настроить суммаризацию маршрутов? Столкнулся с проблемой медленной конвергенции в сети из 200+ маршрутизаторов.',
    author: 'Бакыт Токтогулов',
    authorId: '1',
    createdAt: getDateDaysAgo(2),
    replies: [
      {
        id: '1',
        content: 'Рекомендую использовать иерархическую структуру с backbone area 0 и несколькими обычными areas. Для суммаризации лучше настроить area border routers с командой area X range. Также важно правильно настроить LSA filtering.',
        author: 'Айгуль Мамбетова',
        authorId: '2',
        createdAt: getDateDaysAgo(2)
      },
      {
        id: '2',
        content: 'Согласен с предыдущим комментарием. Добавлю, что для ускорения конвергенции стоит настроить OSPF timers - hello и dead intervals. Также рекомендую использовать BFD (Bidirectional Forwarding Detection) для быстрого обнаружения отказов.',
        author: 'Нурлан Жумабеков',
        authorId: '3',
        createdAt: getDateDaysAgo(1)
      },
      {
        id: '3',
        content: 'Отличные советы! Хочу добавить про важность правильного планирования IP-адресации. Используйте VLSM и старайтесь группировать подсети логически по областям. Это сильно упростит суммаризацию.',
        author: 'Гульмира Асанова',
        authorId: '4',
        createdAt: getDateDaysAgo(1)
      }
    ]
  },
  {
    id: '2',
    title: 'Проблемы с Wi-Fi 7 в офисной среде',
    content: 'Недавно обновили офисную сеть до Wi-Fi 7, но столкнулись с проблемами совместимости со старыми устройствами. Некоторые ноутбуки 2022-2023 года не могут подключиться к новым точкам доступа. Кто-нибудь сталкивался с подобным?',
    author: 'Эрлан Кадыров',
    authorId: '5',
    createdAt: getDateDaysAgo(3),
    replies: [
      {
        id: '4',
        content: 'Это известная проблема. Попробуйте включить legacy mode на точках доступа или создать отдельную сеть для старых устройств. Также проверьте настройки WPA4 - возможно, стоит временно использовать WPA3/WPA4 mixed mode.',
        author: 'Жамила Турдубекова',
        authorId: '6',
        createdAt: getDateDaysAgo(3)
      },
      {
        id: '5',
        content: 'У нас была похожая ситуация. Решили созданием двух SSID - один для новых устройств с Wi-Fi 7, другой для legacy устройств. Это позволило избежать проблем совместимости и получить максимальную производительность от новых устройств.',
        author: 'Темирлан Сыдыков',
        authorId: '7',
        createdAt: getDateDaysAgo(2)
      }
    ]
  },
  {
    id: '3',
    title: 'Выбор между Cisco и Juniper для провайдерской сети в 2025',
    content: 'Планируем модернизацию сети интернет-провайдера. Рассматриваем оборудование Cisco (ASR 9000 серия) и Juniper (PTX серия). Какой производитель лучше для BGP routing и MPLS в 2025? Интересует надежность, производительность и стоимость владения.',
    author: 'Азамат Исаков',
    authorId: '8',
    createdAt: getDateDaysAgo(4),
    replies: [
      {
        id: '6',
        content: 'Работал с обеими платформами. Juniper PTX имеет отличную производительность для BGP и более гибкую конфигурацию. Cisco ASR 9000 надежнее в плане hardware, но дороже в обслуживании. Для MPLS обе платформы хороши, но Juniper лучше для SR-MPLS.',
        author: 'Канат Омуралиев',
        authorId: '9',
        createdAt: getDateDaysAgo(4)
      },
      {
        id: '7',
        content: 'Рекомендую Juniper для core сети - Junos Evolved очень стабильная ОС. Для edge можно рассмотреть Cisco. Также обратите внимание на Nokia SR-series - отличное соотношение цена/качество для провайдерских решений в 2025.',
        author: 'Динара Абдыкадырова',
        authorId: '10',
        createdAt: getDateDaysAgo(3)
      }
    ]
  },
  {
    id: '4',
    title: 'Безопасность в SASE решениях',
    content: 'Изучаю SASE (Secure Access Service Edge) технологии для подключения филиалов. Какие есть особенности обеспечения безопасности в SASE? Достаточно ли встроенного Zero Trust или нужны дополнительные меры защиты?',
    author: 'Айбек Жолдошев',
    authorId: '11',
    createdAt: getDateDaysAgo(5),
    replies: [
      {
        id: '8',
        content: 'SASE включает Zero Trust по умолчанию, но рекомендую дополнительно настроить CASB и DLP политики. Также важно правильно настроить identity-based access control и continuous monitoring для всех подключений.',
        author: 'Мирлан Бейшеналиев',
        authorId: '12',
        createdAt: getDateDaysAgo(5)
      }
    ]
  },
  {
    id: '5',
    title: 'Мониторинг сетевой инфраструктуры: Telemetry vs Traditional SNMP',
    content: 'Какой подход лучше для мониторинга большой сети в 2025 - традиционный SNMP или современные telemetry решения? Рассматриваем внедрение системы мониторинга для сети из 1000+ устройств с поддержкой ИИ-аналитики.',
    author: 'Чолпон Акматова',
    authorId: '13',
    createdAt: getDateDaysAgo(6),
    replies: [
      {
        id: '9',
        content: 'Однозначно telemetry! SNMP уже устарел для больших сетей. Используйте gNMI, NETCONF и streaming telemetry. Для ИИ-аналитики рекомендую Cisco ThousandEyes или Juniper Mist AI - они дают предиктивную аналитику.',
        author: 'Улукбек Турсунов',
        authorId: '14',
        createdAt: getDateDaysAgo(6)
      },
      {
        id: '10',
        content: 'Согласна с telemetry. Добавлю, что для 2025 года обязательно нужна интеграция с ML/AI платформами. Рекомендую посмотреть на OpenTelemetry стандарт и Prometheus + Grafana стек с AI-плагинами.',
        author: 'Бермет Касымова',
        authorId: '15',
        createdAt: getDateDaysAgo(5)
      }
    ]
  },
  {
    id: '6',
    title: 'Настройка EVPN-VXLAN в дата-центре',
    content: 'Помогите с настройкой EVPN-VXLAN на коммутаторах Arista. Нужно создать L2 и L3 VNI для разных тенантов в облачном дата-центре. Какие best practices для BGP EVPN и есть ли особенности по сравнению с Cisco ACI?',
    author: 'Талант Мурзалиев',
    authorId: '16',
    createdAt: getDateDaysAgo(7),
    replies: [
      {
        id: '11',
        content: 'На Arista EOS команды довольно простые. Для EVPN: router bgp, vlan-aware-bundle, route-target. Для VXLAN: interface vxlan1, vxlan source-interface loopback. Главное правильно настроить underlay BGP с ECMP.',
        author: 'Нуржан Алымкулов',
        authorId: '17',
        createdAt: getDateDaysAgo(7)
      },
      {
        id: '12',
        content: 'Добавлю к предыдущему ответу - обязательно используйте anycast gateway для L3 VNI. На Arista это ip virtual-router mac-address. Также рекомендую настроить BUM traffic optimization через ingress replication.',
        author: 'Айжан Токтосунова',
        authorId: '18',
        createdAt: getDateDaysAgo(6)
      }
    ]
  },
  {
    id: '7',
    title: 'Проблемы с производительностью в сети университета после перехода на Wi-Fi 7',
    content: 'В нашем университете проблемы с производительностью сети после обновления до Wi-Fi 7. 5000+ студентов одновременно используют сеть. Пропускная способность интернет-канала 10 Гбит/с. Как оптимизировать для такой нагрузки?',
    author: 'Жаныбек Сатыбалдиев',
    authorId: '19',
    createdAt: getDateDaysAgo(8),
    replies: [
      {
        id: '13',
        content: 'Рекомендую внедрить AI-driven QoS для динамической приоритизации трафика. Образовательные ресурсы и видеоконференции должны иметь высший приоритет. Также стоит рассмотреть per-user bandwidth shaping с ML-алгоритмами.',
        author: 'Гулнара Эсенбекова',
        authorId: '20',
        createdAt: getDateDaysAgo(8)
      },
      {
        id: '14',
        content: 'Согласен с AI QoS. Также предлагаю установить edge computing узлы для кэширования популярного контента и использовать CDN с локальными серверами. Это значительно снизит нагрузку на внешний канал.',
        author: 'Максат Жумагулов',
        authorId: '21',
        createdAt: getDateDaysAgo(7)
      }
    ]
  },
  {
    id: '8',
    title: 'Внедрение IPv6-only сети в корпорации',
    content: 'Планируем полный переход на IPv6-only в нашей компании к концу 2025 года. Какие подводные камни могут быть? Как организовать переходный период и когда можно безопасно отключить IPv4?',
    author: 'Асель Мамытова',
    authorId: '22',
    createdAt: getDateDaysAgo(1),
    replies: [
      {
        id: '15',
        content: 'В 2025 уже можно планировать IPv6-only! Большинство сервисов поддерживают IPv6. Но обязательно оставьте NAT64/DNS64 для legacy приложений. Начните с новых сервисов, постепенно мигрируйте старые. Полное отключение IPv4 - не раньше 2026.',
        author: 'Руслан Абдыкеримов',
        authorId: '23',
        createdAt: getDateDaysAgo(0.5)
      }
    ]
  },
  {
    id: '9',
    title: 'Интеграция ИИ в сетевое управление',
    content: 'Кто-нибудь уже внедрял AI/ML решения для автоматического управления сетью? Интересует опыт с intent-based networking и self-healing networks. Какие платформы лучше использовать в 2025?',
    author: 'Нурбек Алтынбеков',
    authorId: '24',
    createdAt: getDateDaysAgo(0.3),
    replies: [
      {
        id: '16',
        content: 'Мы используем Cisco DNA Center с AI Network Analytics. Очень впечатляет predictive analytics и automated remediation. Система сама обнаруживает и исправляет проблемы до того, как пользователи их заметят. ROI окупился за 8 месяцев.',
        author: 'Мээрим Токтосунова',
        authorId: '25',
        createdAt: getDateDaysAgo(0.1)
      }
    ]
  }
];