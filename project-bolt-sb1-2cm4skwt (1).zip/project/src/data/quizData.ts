import { QuizQuestion } from '../types';

export const quizQuestions: QuizQuestion[] = [
  {
    id: '1',
    question: 'Какой уровень модели OSI отвечает за маршрутизацию пакетов?',
    options: [
      'Физический уровень',
      'Канальный уровень', 
      'Сетевой уровень',
      'Транспортный уровень'
    ],
    correctAnswer: 2,
    explanation: 'Сетевой уровень (Network Layer) отвечает за маршрутизацию пакетов между различными сетями и определение оптимального пути доставки данных.'
  },
  {
    id: '2',
    question: 'Какой протокол используется для автоматического назначения IP-адресов?',
    options: [
      'DNS',
      'HTTP',
      'DHCP',
      'FTP'
    ],
    correctAnswer: 2,
    explanation: 'DHCP (Dynamic Host Configuration Protocol) автоматически назначает IP-адреса, маски подсети, шлюзы по умолчанию и другие сетевые параметры устройствам в сети.'
  },
  {
    id: '3',
    question: 'Что означает аббревиатура VPN?',
    options: [
      'Virtual Private Network',
      'Very Private Network',
      'Virtual Public Network',
      'Verified Private Network'
    ],
    correctAnswer: 0,
    explanation: 'VPN (Virtual Private Network) - это технология, которая создает защищенное соединение через публичную сеть, обеспечивая конфиденциальность и безопасность передачи данных.'
  },
  {
    id: '4',
    question: 'Какой порт по умолчанию использует протокол HTTPS?',
    options: [
      '80',
      '443',
      '8080',
      '21'
    ],
    correctAnswer: 1,
    explanation: 'HTTPS использует порт 443 по умолчанию. Это защищенная версия HTTP с SSL/TLS шифрованием для безопасной передачи данных.'
  },
  {
    id: '5',
    question: 'Что такое NAT в сетевых технологиях?',
    options: [
      'Network Access Token',
      'Network Address Translation',
      'Network Authentication Tool',
      'Network Administration Terminal'
    ],
    correctAnswer: 1,
    explanation: 'NAT (Network Address Translation) - это механизм преобразования IP-адресов, который позволяет нескольким устройствам в локальной сети выходить в интернет через один публичный IP-адрес.'
  },
  {
    id: '6',
    question: 'Какая топология сети обеспечивает наивысшую отказоустойчивость?',
    options: [
      'Звезда',
      'Кольцо',
      'Шина',
      'Полносвязная сетка'
    ],
    correctAnswer: 3,
    explanation: 'Полносвязная сетка (Mesh) обеспечивает наивысшую отказоустойчивость, так как каждый узел соединен со всеми остальными узлами, предоставляя множество альтернативных путей для передачи данных.'
  },
  {
    id: '7',
    question: 'Что означает SaaS в облачных технологиях?',
    options: [
      'Software as a Service',
      'System as a Service',
      'Security as a Service',
      'Storage as a Service'
    ],
    correctAnswer: 0,
    explanation: 'SaaS (Software as a Service) - это модель облачных вычислений, при которой программное обеспечение предоставляется как услуга через интернет без необходимости установки на локальные устройства.'
  },
  {
    id: '8',
    question: 'Какой алгоритм маршрутизации использует протокол OSPF?',
    options: [
      'Distance Vector',
      'Link State',
      'Path Vector',
      'Hybrid'
    ],
    correctAnswer: 1,
    explanation: 'OSPF (Open Shortest Path First) использует алгоритм Link State, который строит полную топологию сети и вычисляет кратчайшие пути с использованием алгоритма Дейкстры.'
  },
  {
    id: '9',
    question: 'Какой уровень модели OSI отвечает за сжатие и шифрование данных?',
    options: [
      'Сеансовый уровень',
      'Представительский уровень',
      'Прикладной уровень',
      'Транспортный уровень'
    ],
    correctAnswer: 1,
    explanation: 'Представительский уровень (Presentation Layer) отвечает за форматирование, сжатие и шифрование данных, обеспечивая их представление в понятном для приложений виде.'
  },
  {
    id: '10',
    question: 'Что такое CDN в веб-технологиях?',
    options: [
      'Content Delivery Network',
      'Central Data Network',
      'Cloud Distribution Network',
      'Cached Data Network'
    ],
    correctAnswer: 0,
    explanation: 'CDN (Content Delivery Network) - это географически распределенная сеть серверов, которая доставляет веб-контент пользователям с ближайшего сервера для повышения скорости загрузки и производительности.'
  }
];