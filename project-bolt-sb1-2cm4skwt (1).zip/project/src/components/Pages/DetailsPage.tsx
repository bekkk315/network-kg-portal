import React, { useState, useEffect } from 'react';
import { Network, Shield, Cloud, Zap, Server, Wifi, Lock, Globe, ArrowRight, ChevronDown, ChevronUp, ArrowLeft } from 'lucide-react';

interface DetailsPageProps {
  onNavigate: (page: string) => void;
}

const DetailsPage: React.FC<DetailsPageProps> = ({ onNavigate }) => {
  const [activeSection, setActiveSection] = useState<string | null>(null);
  const [visibleSections, setVisibleSections] = useState<Set<string>>(new Set());

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setVisibleSections(prev => new Set(prev).add(entry.target.id));
          }
        });
      },
      { threshold: 0.3 }
    );

    document.querySelectorAll('[data-animate]').forEach((el) => {
      observer.observe(el);
    });

    return () => observer.disconnect();
  }, []);

  const sections = [
    {
      id: 'architectures',
      title: 'Сетевые архитектуры',
      icon: Network,
      gradient: 'from-blue-500 to-blue-600',
      content: {
        intro: 'Современные сетевые архитектуры представляют собой основу для построения масштабируемых и надежных ИТ-инфраструктур.',
        topics: [
          {
            title: 'Модель OSI',
            description: 'Семиуровневая модель взаимодействия открытых систем, стандарт для построения сетевых протоколов.'
          },
          {
            title: 'TCP/IP архитектура',
            description: 'Базовая архитектура интернета, включающая протоколы транспортного и сетевого уровней.'
          },
          {
            title: 'Топологии сетей',
            description: 'Звезда, кольцо, шина, сетка - различные способы организации сетевых узлов.'
          },
          {
            title: 'Маршрутизация',
            description: 'Алгоритмы и протоколы для определения оптимальных путей передачи данных.'
          }
        ]
      }
    },
    {
      id: 'protocols',
      title: 'Сетевые протоколы',
      icon: Globe,
      gradient: 'from-indigo-500 to-indigo-600',
      content: {
        intro: 'Протоколы определяют правила взаимодействия между сетевыми устройствами и обеспечивают надежную передачу данных.',
        topics: [
          {
            title: 'HTTP/HTTPS',
            description: 'Протоколы передачи гипертекста для веб-приложений с поддержкой шифрования.'
          },
          {
            title: 'DNS',
            description: 'Система доменных имен для преобразования доменных имен в IP-адреса.'
          },
          {
            title: 'DHCP',
            description: 'Автоматическое назначение IP-адресов и сетевых параметров устройствам.'
          },
          {
            title: 'SNMP',
            description: 'Простой протокол управления сетью для мониторинга и управления сетевыми устройствами.'
          }
        ]
      }
    },
    {
      id: 'security',
      title: 'Безопасность сетей',
      icon: Shield,
      gradient: 'from-red-500 to-red-600',
      content: {
        intro: 'Безопасность сетей является критически важным аспектом современных ИТ-систем, требующим комплексного подхода.',
        topics: [
          {
            title: 'Firewalls',
            description: 'Межсетевые экраны для фильтрации трафика и защиты от несанкционированного доступа.'
          },
          {
            title: 'VPN',
            description: 'Виртуальные частные сети для безопасного удаленного доступа к корпоративным ресурсам.'
          },
          {
            title: 'Шифрование',
            description: 'Алгоритмы и методы защиты данных при передаче по сети.'
          },
          {
            title: 'Аутентификация',
            description: 'Методы проверки подлинности пользователей и устройств в сети.'
          }
        ]
      }
    },
    {
      id: 'cloud',
      title: 'Облачные технологии',
      icon: Cloud,
      gradient: 'from-purple-500 to-purple-600',
      content: {
        intro: 'Облачные технологии революционизируют способы развертывания и управления сетевой инфраструктурой.',
        topics: [
          {
            title: 'IaaS',
            description: 'Инфраструктура как сервис - предоставление виртуализированных вычислительных ресурсов.'
          },
          {
            title: 'PaaS',
            description: 'Платформа как сервис - среда разработки и развертывания приложений.'
          },
          {
            title: 'SaaS',
            description: 'Программное обеспечение как сервис - готовые приложения, доступные через интернет.'
          },
          {
            title: 'Гибридные облака',
            description: 'Сочетание публичных и частных облачных решений для оптимальной гибкости.'
          }
        ]
      }
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      {/* Back Navigation */}
      <div className="bg-white shadow-sm border-b sticky top-0 z-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <button
            onClick={() => onNavigate('home')}
            className="flex items-center text-blue-600 hover:text-blue-700 transition-colors font-medium"
          >
            <ArrowLeft className="h-5 w-5 mr-2" />
            На главную
          </button>
        </div>
      </div>

      {/* Header */}
      <section className="relative pt-16 pb-12 px-4 sm:px-6 lg:px-8 bg-gradient-to-r from-slate-900 to-blue-900">
        <div className="max-w-7xl mx-auto text-center">
          <h1 className="text-5xl md:text-6xl font-bold text-white mb-6">
            Теория сетевых <span className="bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">технологий</span>
          </h1>
          <p className="text-xl text-slate-300 max-w-3xl mx-auto">
            Комплексное изучение современных сетевых технологий, архитектур, протоколов и облачных решений
          </p>
        </div>
      </section>

      {/* Navigation */}
      <section className="sticky top-16 z-10 bg-white shadow-md border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex overflow-x-auto py-4 space-x-6">
            {sections.map((section) => {
              const Icon = section.icon;
              return (
                <button
                  key={section.id}
                  onClick={() => {
                    const element = document.getElementById(section.id);
                    element?.scrollIntoView({ behavior: 'smooth' });
                  }}
                  className={`flex items-center space-x-2 px-4 py-2 rounded-lg font-medium transition-all duration-200 whitespace-nowrap ${
                    activeSection === section.id
                      ? 'bg-blue-100 text-blue-700'
                      : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                  }`}
                >
                  <Icon className="h-4 w-4" />
                  <span>{section.title}</span>
                </button>
              );
            })}
          </div>
        </div>
      </section>

      {/* Content Sections */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {sections.map((section, index) => {
          const Icon = section.icon;
          const isVisible = visibleSections.has(section.id);
          const isExpanded = activeSection === section.id;
          
          return (
            <section
              key={section.id}
              id={section.id}
              data-animate
              className={`mb-16 transform transition-all duration-700 ${
                isVisible ? 'translate-y-0 opacity-100' : 'translate-y-8 opacity-0'
              }`}
            >
              <div className="bg-white rounded-2xl shadow-xl overflow-hidden">
                <div className={`bg-gradient-to-r ${section.gradient} p-8`}>
                  <div className="flex items-center space-x-4">
                    <div className="p-3 bg-white bg-opacity-20 rounded-xl">
                      <Icon className="h-8 w-8 text-white" />
                    </div>
                    <div>
                      <h2 className="text-3xl font-bold text-white">{section.title}</h2>
                      <p className="text-white text-opacity-90 mt-2">{section.content.intro}</p>
                    </div>
                  </div>
                </div>

                <div className="p-8">
                  <div className="grid md:grid-cols-2 gap-6">
                    {section.content.topics.map((topic, topicIndex) => (
                      <div
                        key={topicIndex}
                        className={`p-6 bg-gradient-to-br from-gray-50 to-white rounded-xl border border-gray-200 hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1 ${
                          isVisible ? `animate-fade-in-up` : ''
                        }`}
                        style={{ animationDelay: `${topicIndex * 100}ms` }}
                      >
                        <h3 className="text-xl font-semibold text-gray-900 mb-3">{topic.title}</h3>
                        <p className="text-gray-600 leading-relaxed">{topic.description}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </section>
          );
        })}
      </div>

      {/* CTA Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gradient-to-r from-blue-600 to-indigo-700">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl font-bold text-white mb-6">
            Готовы проверить свои знания?
          </h2>
          <p className="text-xl text-blue-100 mb-8">
            Пройдите интерактивный тест и оцените уровень своих знаний в области сетевых технологий
          </p>
          <button
            onClick={() => onNavigate('quiz')}
            className="inline-flex items-center px-8 py-4 bg-white text-blue-600 font-semibold rounded-xl hover:bg-gray-100 transition-all duration-200 shadow-lg hover:shadow-xl transform hover:-translate-y-1"
          >
            Пройти тест
            <ArrowRight className="ml-2 h-5 w-5" />
          </button>
        </div>
      </section>

      <style jsx>{`
        @keyframes fade-in-up {
          from {
            opacity: 0;
            transform: translateY(20px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        
        .animate-fade-in-up {
          animation: fade-in-up 0.6s ease-out forwards;
        }
      `}</style>
    </div>
  );
};

export default DetailsPage;