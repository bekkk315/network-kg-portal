import React, { useState, useEffect } from 'react';
import { 
  User, 
  Trophy, 
  Target, 
  Calendar, 
  Clock, 
  Star, 
  Award, 
  BookOpen, 
  MessageSquare, 
  TrendingUp,
  Settings,
  Edit3,
  Camera,
  Save,
  X,
  Medal,
  Zap,
  Brain,
  Shield,
  Crown,
  Flame,
  CheckCircle,
  ArrowLeft
} from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';

interface ProfilePageProps {
  onNavigate: (page: string) => void;
}

interface UserStats {
  quizzesCompleted: number;
  averageScore: number;
  totalPoints: number;
  coursesWatched: number;
  forumPosts: number;
  studyStreak: number;
  level: number;
  achievements: Achievement[];
}

interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: any;
  color: string;
  unlocked: boolean;
  unlockedAt?: string;
}

const ProfilePage: React.FC<ProfilePageProps> = ({ onNavigate }) => {
  const { user } = useAuth();
  const [isEditing, setIsEditing] = useState(false);
  const [editedName, setEditedName] = useState(user?.name || '');
  const [selectedAvatar, setSelectedAvatar] = useState(0);
  const [userStats, setUserStats] = useState<UserStats | null>(null);

  const avatars = [
    '👨‍💻', '👩‍💻', '🧑‍🎓', '👨‍🔬', '👩‍🔬', '🧑‍💼', 
    '👨‍🏫', '👩‍🏫', '🧑‍🚀', '👨‍⚕️', '👩‍⚕️', '🧑‍🎨'
  ];

  // Получаем даты относительно 19 июня 2025
  const getCurrentDate = () => new Date('2025-06-19T12:00:00Z').toISOString();
  const getDateDaysAgo = (days: number) => {
    const date = new Date('2025-06-19T12:00:00Z');
    date.setDate(date.getDate() - days);
    return date.toISOString();
  };

  const achievements: Achievement[] = [
    {
      id: 'first_quiz',
      title: 'Первые шаги',
      description: 'Прошли первый тест',
      icon: Target,
      color: 'from-green-400 to-green-600',
      unlocked: true,
      unlockedAt: getDateDaysAgo(5)
    },
    {
      id: 'quiz_master',
      title: 'Мастер тестов',
      description: 'Прошли 15 тестов',
      icon: Brain,
      color: 'from-blue-400 to-blue-600',
      unlocked: true,
      unlockedAt: getDateDaysAgo(3)
    },
    {
      id: 'perfect_score',
      title: 'Идеальный результат',
      description: 'Набрали 100% в тесте',
      icon: Crown,
      color: 'from-yellow-400 to-yellow-600',
      unlocked: true,
      unlockedAt: getDateDaysAgo(7)
    },
    {
      id: 'course_watcher',
      title: 'Любитель курсов',
      description: 'Посмотрели 8 курсов',
      icon: BookOpen,
      color: 'from-purple-400 to-purple-600',
      unlocked: true,
      unlockedAt: getDateDaysAgo(10)
    },
    {
      id: 'forum_active',
      title: 'Активный участник',
      description: 'Написали 10 сообщений на форуме',
      icon: MessageSquare,
      color: 'from-indigo-400 to-indigo-600',
      unlocked: false
    },
    {
      id: 'streak_week',
      title: 'Месяц подряд',
      description: 'Занимались 30 дней подряд',
      icon: Flame,
      color: 'from-red-400 to-red-600',
      unlocked: true,
      unlockedAt: getDateDaysAgo(2)
    },
    {
      id: 'network_expert',
      title: 'Эксперт сетей',
      description: 'Достигли 5 уровня',
      icon: Shield,
      color: 'from-emerald-400 to-emerald-600',
      unlocked: false
    },
    {
      id: 'speed_demon',
      title: 'Скоростной демон',
      description: 'Прошли тест за 2 минуты',
      icon: Zap,
      color: 'from-orange-400 to-orange-600',
      unlocked: true,
      unlockedAt: getDateDaysAgo(1)
    }
  ];

  useEffect(() => {
    // Симуляция загрузки статистики пользователя
    const loadUserStats = () => {
      const stats: UserStats = {
        quizzesCompleted: 18,
        averageScore: 89,
        totalPoints: 3250,
        coursesWatched: 12,
        forumPosts: 8,
        studyStreak: 25,
        level: 6,
        achievements: achievements
      };
      setUserStats(stats);
    };

    loadUserStats();
  }, []);

  const handleSaveProfile = () => {
    // Здесь можно добавить логику сохранения профиля
    setIsEditing(false);
  };

  const getLevelProgress = (level: number) => {
    const currentLevelPoints = (level - 1) * 500;
    const nextLevelPoints = level * 500;
    const progress = ((userStats?.totalPoints || 0) - currentLevelPoints) / (nextLevelPoints - currentLevelPoints) * 100;
    return Math.min(Math.max(progress, 0), 100);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('ru-RU', {
      day: 'numeric',
      month: 'short',
      year: 'numeric'
    });
  };

  const getTimeAgo = (dateString: string) => {
    const now = new Date('2025-06-19T12:00:00Z');
    const date = new Date(dateString);
    const diffInHours = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60));
    
    if (diffInHours < 1) return 'Только что';
    if (diffInHours < 24) return `${diffInHours} ч. назад`;
    if (diffInHours < 48) return 'Вчера';
    const days = Math.floor(diffInHours / 24);
    if (days < 7) return `${days} дн. назад`;
    return formatDate(dateString);
  };

  // Генерируем календарь для июня 2025
  const generateJuneCalendar = () => {
    const calendar = [];
    const daysInJune = 30;
    const startDay = 0; // Июнь 2025 начинается с воскресенья
    
    // Добавляем пустые ячейки для дней предыдущего месяца
    for (let i = 0; i < startDay; i++) {
      calendar.push(null);
    }
    
    // Добавляем дни июня
    for (let day = 1; day <= daysInJune; day++) {
      calendar.push(day);
    }
    
    return calendar;
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center px-4">
        <div className="max-w-md w-full bg-white rounded-2xl shadow-xl p-8 text-center">
          <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <User className="h-8 w-8 text-blue-600" />
          </div>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Требуется авторизация</h2>
          <p className="text-gray-600 mb-6">
            Для просмотра профиля необходимо войти в систему
          </p>
          <button
            onClick={() => onNavigate('login')}
            className="w-full bg-blue-600 text-white py-3 px-4 rounded-lg hover:bg-blue-700 transition-colors font-medium"
          >
            Войти в систему
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      {/* Back Navigation */}
      <div className="bg-white shadow-sm border-b sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <button
            onClick={() => onNavigate('home')}
            className="flex items-center text-blue-600 hover:text-blue-700 transition-colors font-medium"
          >
            <ArrowLeft className="h-5 w-5 mr-2" />
            На главную
          </button>
        </div>
      </div>

      {/* Header */}
      <section className="relative pt-16 pb-12 px-4 sm:px-6 lg:px-8 bg-gradient-to-r from-slate-900 to-blue-900">
        <div className="max-w-7xl mx-auto">
          <div className="text-center">
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
              Личный <span className="bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">кабинет</span>
            </h1>
            <p className="text-xl text-slate-300 max-w-3xl mx-auto">
              Ваш прогресс, достижения и статистика обучения в 2025 году
            </p>
          </div>
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Profile Card */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-2xl shadow-xl p-8 mb-8">
              <div className="text-center">
                <div className="relative inline-block mb-6">
                  <div className="w-24 h-24 bg-gradient-to-r from-blue-500 to-indigo-600 rounded-full flex items-center justify-center text-4xl">
                    {avatars[selectedAvatar]}
                  </div>
                  {isEditing && (
                    <button className="absolute -bottom-2 -right-2 bg-blue-600 text-white p-2 rounded-full hover:bg-blue-700 transition-colors">
                      <Camera className="h-4 w-4" />
                    </button>
                  )}
                </div>

                {isEditing ? (
                  <div className="space-y-4">
                    <input
                      type="text"
                      value={editedName}
                      onChange={(e) => setEditedName(e.target.value)}
                      className="w-full text-center text-xl font-bold border border-gray-300 rounded-lg py-2 px-4 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                    <div className="grid grid-cols-6 gap-2">
                      {avatars.map((avatar, index) => (
                        <button
                          key={index}
                          onClick={() => setSelectedAvatar(index)}
                          className={`text-2xl p-2 rounded-lg border-2 transition-all ${
                            selectedAvatar === index 
                              ? 'border-blue-500 bg-blue-50' 
                              : 'border-gray-200 hover:border-gray-300'
                          }`}
                        >
                          {avatar}
                        </button>
                      ))}
                    </div>
                    <div className="flex space-x-2">
                      <button
                        onClick={handleSaveProfile}
                        className="flex-1 bg-green-600 text-white py-2 px-4 rounded-lg hover:bg-green-700 transition-colors flex items-center justify-center"
                      >
                        <Save className="h-4 w-4 mr-2" />
                        Сохранить
                      </button>
                      <button
                        onClick={() => setIsEditing(false)}
                        className="flex-1 bg-gray-600 text-white py-2 px-4 rounded-lg hover:bg-gray-700 transition-colors flex items-center justify-center"
                      >
                        <X className="h-4 w-4 mr-2" />
                        Отмена
                      </button>
                    </div>
                  </div>
                ) : (
                  <div>
                    <h2 className="text-2xl font-bold text-gray-900 mb-2">{user.name}</h2>
                    <p className="text-gray-600 mb-4">{user.email}</p>
                    <div className="flex items-center justify-center space-x-2 mb-4">
                      <div className="bg-gradient-to-r from-yellow-400 to-yellow-600 text-white px-3 py-1 rounded-full text-sm font-medium flex items-center">
                        <Crown className="h-4 w-4 mr-1" />
                        Уровень {userStats?.level}
                      </div>
                      {user.role === 'admin' && (
                        <div className="bg-gradient-to-r from-purple-400 to-purple-600 text-white px-3 py-1 rounded-full text-sm font-medium">
                          Админ
                        </div>
                      )}
                    </div>
                    <p className="text-sm text-gray-500 mb-4">
                      Участник с {new Date(user.joinDate).toLocaleDateString('ru-RU', { month: 'long', year: 'numeric' })}
                    </p>
                    <button
                      onClick={() => setIsEditing(true)}
                      className="bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors flex items-center mx-auto"
                    >
                      <Edit3 className="h-4 w-4 mr-2" />
                      Редактировать
                    </button>
                  </div>
                )}
              </div>

              {/* Level Progress */}
              {userStats && (
                <div className="mt-8 p-4 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-medium text-gray-700">Прогресс уровня</span>
                    <span className="text-sm text-gray-600">{userStats.totalPoints} XP</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-3">
                    <div
                      className="bg-gradient-to-r from-blue-500 to-indigo-600 h-3 rounded-full transition-all duration-500"
                      style={{ width: `${getLevelProgress(userStats.level)}%` }}
                    ></div>
                  </div>
                  <p className="text-xs text-gray-600 mt-2">
                    {500 - (userStats.totalPoints % 500)} XP до следующего уровня
                  </p>
                </div>
              )}
            </div>

            {/* Quick Stats */}
            <div className="bg-white rounded-2xl shadow-xl p-6">
              <h3 className="text-lg font-bold text-gray-900 mb-4 flex items-center">
                <TrendingUp className="h-5 w-5 mr-2 text-blue-600" />
                Статистика 2025
              </h3>
              {userStats && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">Тесты пройдены</span>
                    <span className="font-bold text-blue-600">{userStats.quizzesCompleted}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">Средний балл</span>
                    <span className="font-bold text-green-600">{userStats.averageScore}%</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">Курсы просмотрены</span>
                    <span className="font-bold text-purple-600">{userStats.coursesWatched}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">Дни подряд</span>
                    <span className="font-bold text-red-600 flex items-center">
                      <Flame className="h-4 w-4 mr-1" />
                      {userStats.studyStreak}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">Сообщений на форуме</span>
                    <span className="font-bold text-indigo-600">{userStats.forumPosts}</span>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Achievements */}
            <div className="bg-white rounded-2xl shadow-xl p-8">
              <h3 className="text-2xl font-bold text-gray-900 mb-6 flex items-center">
                <Trophy className="h-6 w-6 mr-3 text-yellow-600" />
                Достижения 2025
              </h3>
              <div className="grid md:grid-cols-2 gap-4">
                {achievements.map((achievement) => {
                  const Icon = achievement.icon;
                  return (
                    <div
                      key={achievement.id}
                      className={`p-4 rounded-xl border-2 transition-all duration-300 ${
                        achievement.unlocked
                          ? 'border-transparent bg-gradient-to-r ' + achievement.color + ' text-white shadow-lg transform hover:scale-105'
                          : 'border-gray-200 bg-gray-50 text-gray-400 hover:border-gray-300'
                      }`}
                    >
                      <div className="flex items-start space-x-3">
                        <div className={`p-2 rounded-lg ${
                          achievement.unlocked ? 'bg-white bg-opacity-20' : 'bg-gray-200'
                        }`}>
                          <Icon className="h-5 w-5" />
                        </div>
                        <div className="flex-1">
                          <h4 className="font-semibold mb-1">{achievement.title}</h4>
                          <p className={`text-sm ${
                            achievement.unlocked ? 'text-white text-opacity-90' : 'text-gray-500'
                          }`}>
                            {achievement.description}
                          </p>
                          {achievement.unlocked && achievement.unlockedAt && (
                            <p className="text-xs text-white text-opacity-75 mt-2">
                              Получено: {getTimeAgo(achievement.unlockedAt)}
                            </p>
                          )}
                        </div>
                        {achievement.unlocked && (
                          <CheckCircle className="h-5 w-5 text-white" />
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Activity Chart */}
            <div className="bg-white rounded-2xl shadow-xl p-8">
              <h3 className="text-2xl font-bold text-gray-900 mb-6 flex items-center">
                <Calendar className="h-6 w-6 mr-3 text-blue-600" />
                Активность за июнь 2025
              </h3>
              <div className="grid grid-cols-7 gap-2 mb-4">
                <div className="text-xs text-gray-500 text-center py-2">Вс</div>
                <div className="text-xs text-gray-500 text-center py-2">Пн</div>
                <div className="text-xs text-gray-500 text-center py-2">Вт</div>
                <div className="text-xs text-gray-500 text-center py-2">Ср</div>
                <div className="text-xs text-gray-500 text-center py-2">Чт</div>
                <div className="text-xs text-gray-500 text-center py-2">Пт</div>
                <div className="text-xs text-gray-500 text-center py-2">Сб</div>
              </div>
              <div className="grid grid-cols-7 gap-2">
                {generateJuneCalendar().map((day, index) => {
                  if (day === null) {
                    return <div key={index} className="aspect-square"></div>;
                  }
                  
                  // Симулируем реальную активность с большей активностью в будние дни
                  const dayOfWeek = index % 7;
                  const isWeekend = dayOfWeek === 0 || dayOfWeek === 6;
                  const isToday = day === 19;
                  const isPastDay = day < 19;
                  
                  let activity = 0;
                  if (isPastDay) {
                    const baseActivity = isWeekend ? 0.2 : 0.7;
                    activity = Math.random() * 0.3 + baseActivity;
                  } else if (isToday) {
                    activity = 0.9; // Высокая активность сегодня
                  }
                  
                  return (
                    <div
                      key={index}
                      className={`aspect-square rounded-lg transition-all duration-200 hover:scale-110 cursor-pointer border-2 ${
                        isToday ? 'border-blue-500 bg-blue-600' :
                        activity > 0.8 ? 'border-transparent bg-green-600' :
                        activity > 0.6 ? 'border-transparent bg-green-500' :
                        activity > 0.4 ? 'border-transparent bg-green-300' :
                        activity > 0.2 ? 'border-transparent bg-green-200' :
                        isPastDay ? 'border-transparent bg-gray-100' :
                        'border-gray-200 bg-gray-50'
                      }`}
                      title={`${day} июня 2025 ${isToday ? '(сегодня)' : ''} - ${Math.round(activity * 100)}% активности`}
                    >
                      <div className={`w-full h-full flex items-center justify-center text-xs font-medium ${
                        isToday ? 'text-white' : 'text-gray-700'
                      }`}>
                        {day}
                      </div>
                    </div>
                  );
                })}
              </div>
              <div className="flex items-center justify-between mt-6 text-sm text-gray-600">
                <span>Меньше активности</span>
                <div className="flex space-x-1">
                  <div className="w-3 h-3 bg-gray-100 rounded"></div>
                  <div className="w-3 h-3 bg-green-200 rounded"></div>
                  <div className="w-3 h-3 bg-green-300 rounded"></div>
                  <div className="w-3 h-3 bg-green-500 rounded"></div>
                  <div className="w-3 h-3 bg-green-600 rounded"></div>
                </div>
                <span>Больше активности</span>
              </div>
            </div>

            {/* Recent Activity */}
            <div className="bg-white rounded-2xl shadow-xl p-8">
              <h3 className="text-2xl font-bold text-gray-900 mb-6 flex items-center">
                <Clock className="h-6 w-6 mr-3 text-indigo-600" />
                Последняя активность
              </h3>
              <div className="space-y-4">
                <div className="flex items-center space-x-4 p-4 bg-blue-50 rounded-xl border-l-4 border-blue-500">
                  <div className="p-2 bg-blue-100 rounded-lg">
                    <Target className="h-5 w-5 text-blue-600" />
                  </div>
                  <div className="flex-1">
                    <p className="font-medium text-gray-900">Прошли тест "Сетевые протоколы IPv6"</p>
                    <p className="text-sm text-gray-600">Результат: 10/10 (100%) • {getTimeAgo(getDateDaysAgo(0.1))}</p>
                  </div>
                  <div className="text-green-600 font-bold">+200 XP</div>
                </div>
                
                <div className="flex items-center space-x-4 p-4 bg-purple-50 rounded-xl border-l-4 border-purple-500">
                  <div className="p-2 bg-purple-100 rounded-lg">
                    <BookOpen className="h-5 w-5 text-purple-600" />
                  </div>
                  <div className="flex-1">
                    <p className="font-medium text-gray-900">Посмотрели курс "6G технологии"</p>
                    <p className="text-sm text-gray-600">Преподаватель: Эрлан Кадыров • {getTimeAgo(getDateDaysAgo(1))}</p>
                  </div>
                  <div className="text-green-600 font-bold">+150 XP</div>
                </div>
                
                <div className="flex items-center space-x-4 p-4 bg-indigo-50 rounded-xl border-l-4 border-indigo-500">
                  <div className="p-2 bg-indigo-100 rounded-lg">
                    <MessageSquare className="h-5 w-5 text-indigo-600" />
                  </div>
                  <div className="flex-1">
                    <p className="font-medium text-gray-900">Оставили комментарий на форуме</p>
                    <p className="text-sm text-gray-600">Тема: "Интеграция ИИ в сетевое управление" • {getTimeAgo(getDateDaysAgo(0.3))}</p>
                  </div>
                  <div className="text-green-600 font-bold">+75 XP</div>
                </div>

                <div className="flex items-center space-x-4 p-4 bg-yellow-50 rounded-xl border-l-4 border-yellow-500">
                  <div className="p-2 bg-yellow-100 rounded-lg">
                    <Crown className="h-5 w-5 text-yellow-600" />
                  </div>
                  <div className="flex-1">
                    <p className="font-medium text-gray-900">Получили достижение "Скоростной демон"</p>
                    <p className="text-sm text-gray-600">За быстрое прохождение теста • {getTimeAgo(getDateDaysAgo(1))}</p>
                  </div>
                  <div className="text-yellow-600 font-bold">🏆</div>
                </div>

                <div className="flex items-center space-x-4 p-4 bg-green-50 rounded-xl border-l-4 border-green-500">
                  <div className="p-2 bg-green-100 rounded-lg">
                    <Flame className="h-5 w-5 text-green-600" />
                  </div>
                  <div className="flex-1">
                    <p className="font-medium text-gray-900">Продлили серию обучения</p>
                    <p className="text-sm text-gray-600">25 дней подряд! Невероятно! • {getTimeAgo(getDateDaysAgo(0.5))}</p>
                  </div>
                  <div className="text-green-600 font-bold">+50 XP</div>
                </div>
              </div>
            </div>

            {/* Year Summary */}
            <div className="bg-gradient-to-r from-blue-600 to-indigo-700 rounded-2xl shadow-xl p-8 text-white">
              <h3 className="text-2xl font-bold mb-6 flex items-center">
                <Star className="h-6 w-6 mr-3" />
                Итоги первой половины 2025 года
              </h3>
              <div className="grid md:grid-cols-3 gap-6">
                <div className="text-center">
                  <div className="text-3xl font-bold mb-2">3,250</div>
                  <div className="text-blue-200">Общий XP заработан</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold mb-2">6</div>
                  <div className="text-blue-200">Достижений получено</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold mb-2">89%</div>
                  <div className="text-blue-200">Средний результат</div>
                </div>
              </div>
              <div className="mt-6 p-4 bg-white bg-opacity-10 rounded-lg">
                <p className="text-center text-blue-100">
                  🎉 Поздравляем! Вы входите в топ-15% самых активных пользователей Network KG в 2025 году!
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProfilePage;