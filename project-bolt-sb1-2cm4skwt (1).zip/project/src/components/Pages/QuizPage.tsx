import React, { useState, useEffect } from 'react';
import { HelpCircle, CheckCircle, XCircle, RotateCcw, Trophy, Clock, Target, ArrowLeft } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { quizQuestions } from '../../data/quizData';
import { QuizResult } from '../../types';

interface QuizPageProps {
  onNavigate: (page: string) => void;
}

const QuizPage: React.FC<QuizPageProps> = ({ onNavigate }) => {
  const { user } = useAuth();
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [answers, setAnswers] = useState<number[]>([]);
  const [showResult, setShowResult] = useState(false);
  const [isCompleted, setIsCompleted] = useState(false);
  const [timeLeft, setTimeLeft] = useState(600); // 10 minutes
  const [showExplanation, setShowExplanation] = useState(false);

  useEffect(() => {
    if (!isCompleted && timeLeft > 0) {
      const timer = setTimeout(() => setTimeLeft(timeLeft - 1), 1000);
      return () => clearTimeout(timer);
    } else if (timeLeft === 0 && !isCompleted) {
      handleQuizComplete();
    }
  }, [timeLeft, isCompleted]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const handleAnswerSelect = (answerIndex: number) => {
    setSelectedAnswer(answerIndex);
  };

  const handleNextQuestion = () => {
    if (selectedAnswer === null) return;

    const newAnswers = [...answers];
    newAnswers[currentQuestion] = selectedAnswer;
    setAnswers(newAnswers);

    if (currentQuestion < quizQuestions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
      setSelectedAnswer(null);
      setShowExplanation(false);
    } else {
      handleQuizComplete(newAnswers);
    }
  };

  const handleShowExplanation = () => {
    if (selectedAnswer === null) return;
    setShowExplanation(true);
  };

  const handleQuizComplete = (finalAnswers = answers) => {
    const score = finalAnswers.reduce((total, answer, index) => {
      return total + (answer === quizQuestions[index].correctAnswer ? 1 : 0);
    }, 0);

    const result: QuizResult = {
      id: Date.now().toString(),
      userId: user?.id || 'anonymous',
      score,
      totalQuestions: quizQuestions.length,
      completedAt: new Date().toISOString(),
    };

    // Save result to localStorage
    const savedResults = JSON.parse(localStorage.getItem('networkkg_quiz_results') || '[]');
    savedResults.push(result);
    localStorage.setItem('networkkg_quiz_results', JSON.stringify(savedResults));

    setIsCompleted(true);
    setShowResult(true);
  };

  const resetQuiz = () => {
    setCurrentQuestion(0);
    setSelectedAnswer(null);
    setAnswers([]);
    setShowResult(false);
    setIsCompleted(false);
    setTimeLeft(600);
    setShowExplanation(false);
  };

  const getScoreColor = (score: number, total: number) => {
    const percentage = (score / total) * 100;
    if (percentage >= 80) return 'text-green-600';
    if (percentage >= 60) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getScoreMessage = (score: number, total: number) => {
    const percentage = (score / total) * 100;
    if (percentage >= 90) return 'Превосходно! Вы отлично знаете сетевые технологии!';
    if (percentage >= 80) return 'Очень хорошо! У вас солидные знания в области сетей.';
    if (percentage >= 60) return 'Хорошо! Есть области для улучшения знаний.';
    if (percentage >= 40) return 'Неплохо, но стоит изучить материал более глубоко.';
    return 'Рекомендуем повторить теоретический материал.';
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center px-4">
        <div className="max-w-md w-full bg-white rounded-2xl shadow-xl p-8 text-center">
          <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <HelpCircle className="h-8 w-8 text-blue-600" />
          </div>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Требуется авторизация</h2>
          <p className="text-gray-600 mb-6">
            Для прохождения теста необходимо войти в систему
          </p>
          <button
            onClick={() => onNavigate('login')}
            className="w-full bg-blue-600 text-white py-3 px-4 rounded-lg hover:bg-blue-700 transition-colors font-medium"
          >
            Войти в систему
          </button>
        </div>
      </div>
    );
  }

  if (showResult) {
    const score = answers.reduce((total, answer, index) => {
      return total + (answer === quizQuestions[index].correctAnswer ? 1 : 0);
    }, 0);

    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
        {/* Back Navigation */}
        <div className="bg-white shadow-sm border-b">
          <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
            <button
              onClick={() => onNavigate('home')}
              className="flex items-center text-blue-600 hover:text-blue-700 transition-colors font-medium"
            >
              <ArrowLeft className="h-5 w-5 mr-2" />
              На главную
            </button>
          </div>
        </div>

        <div className="flex items-center justify-center px-4 py-8">
          <div className="max-w-2xl w-full bg-white rounded-2xl shadow-xl p-8">
            <div className="text-center mb-8">
              <div className="w-20 h-20 bg-gradient-to-r from-blue-500 to-indigo-600 rounded-full flex items-center justify-center mx-auto mb-6">
                <Trophy className="h-10 w-10 text-white" />
              </div>
              <h2 className="text-3xl font-bold text-gray-900 mb-4">Тест завершен!</h2>
              <div className={`text-6xl font-bold mb-4 ${getScoreColor(score, quizQuestions.length)}`}>
                {score}/{quizQuestions.length}
              </div>
              <p className="text-xl text-gray-600 mb-2">
                {getScoreMessage(score, quizQuestions.length)}
              </p>
              <p className="text-gray-500">
                Процент правильных ответов: {Math.round((score / quizQuestions.length) * 100)}%
              </p>
            </div>

            <div className="grid md:grid-cols-3 gap-4 mb-8">
              <div className="bg-blue-50 p-4 rounded-lg text-center">
                <Target className="h-6 w-6 text-blue-600 mx-auto mb-2" />
                <div className="text-2xl font-bold text-blue-600">{score}</div>
                <div className="text-sm text-gray-600">Правильных ответов</div>
              </div>
              <div className="bg-green-50 p-4 rounded-lg text-center">
                <CheckCircle className="h-6 w-6 text-green-600 mx-auto mb-2" />
                <div className="text-2xl font-bold text-green-600">{Math.round((score / quizQuestions.length) * 100)}%</div>
                <div className="text-sm text-gray-600">Точность</div>
              </div>
              <div className="bg-purple-50 p-4 rounded-lg text-center">
                <Clock className="h-6 w-6 text-purple-600 mx-auto mb-2" />
                <div className="text-2xl font-bold text-purple-600">{formatTime(600 - timeLeft)}</div>
                <div className="text-sm text-gray-600">Затрачено времени</div>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-4">
              <button
                onClick={resetQuiz}
                className="flex-1 bg-blue-600 text-white py-3 px-4 rounded-lg hover:bg-blue-700 transition-colors font-medium flex items-center justify-center"
              >
                <RotateCcw className="h-5 w-5 mr-2" />
                Пройти еще раз
              </button>
              <button
                onClick={() => onNavigate('details')}
                className="flex-1 bg-gray-100 text-gray-700 py-3 px-4 rounded-lg hover:bg-gray-200 transition-colors font-medium"
              >
                Изучить теорию
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  const question = quizQuestions[currentQuestion];
  const progress = ((currentQuestion + 1) / quizQuestions.length) * 100;

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Back Navigation */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <button
            onClick={() => onNavigate('home')}
            className="flex items-center text-blue-600 hover:text-blue-700 transition-colors font-medium"
          >
            <ArrowLeft className="h-5 w-5 mr-2" />
            На главную
          </button>
        </div>
      </div>

      <div className="py-8 px-4">
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <div className="bg-white rounded-2xl shadow-lg p-6 mb-6">
            <div className="flex items-center justify-between mb-4">
              <h1 className="text-2xl font-bold text-gray-900">Тест по сетевым технологиям</h1>
              <div className="flex items-center space-x-4">
                <div className="flex items-center text-gray-600">
                  <Clock className="h-5 w-5 mr-2" />
                  <span className="font-mono text-lg">{formatTime(timeLeft)}</span>
                </div>
                <div className="text-gray-600">
                  {currentQuestion + 1} / {quizQuestions.length}
                </div>
              </div>
            </div>
            
            <div className="w-full bg-gray-200 rounded-full h-3">
              <div
                className="bg-gradient-to-r from-blue-500 to-indigo-600 h-3 rounded-full transition-all duration-500"
                style={{ width: `${progress}%` }}
              ></div>
            </div>
          </div>

          {/* Question */}
          <div className="bg-white rounded-2xl shadow-lg p-8">
            <div className="mb-8">
              <div className="flex items-start space-x-4">
                <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                  <HelpCircle className="h-5 w-5 text-blue-600" />
                </div>
                <div className="flex-1">
                  <h2 className="text-xl font-semibold text-gray-900 mb-4">
                    {question.question}
                  </h2>
                </div>
              </div>
            </div>

            <div className="space-y-3 mb-8">
              {question.options.map((option, index) => (
                <button
                  key={index}
                  onClick={() => handleAnswerSelect(index)}
                  className={`w-full p-4 text-left rounded-lg border-2 transition-all duration-200 ${
                    selectedAnswer === index
                      ? showExplanation
                        ? index === question.correctAnswer
                          ? 'border-green-500 bg-green-50 text-green-800'
                          : 'border-red-500 bg-red-50 text-red-800'
                        : 'border-blue-500 bg-blue-50 text-blue-800'
                      : showExplanation && index === question.correctAnswer
                      ? 'border-green-500 bg-green-50 text-green-800'
                      : 'border-gray-300 hover:border-gray-400 hover:bg-gray-50'
                  }`}
                  disabled={showExplanation}
                >
                  <div className="flex items-center">
                    <span className="w-6 h-6 rounded-full border-2 border-current mr-3 flex items-center justify-center text-xs font-bold">
                      {String.fromCharCode(65 + index)}
                    </span>
                    <span className="font-medium">{option}</span>
                    {showExplanation && (
                      <div className="ml-auto">
                        {index === question.correctAnswer ? (
                          <CheckCircle className="h-5 w-5 text-green-600" />
                        ) : selectedAnswer === index ? (
                          <XCircle className="h-5 w-5 text-red-600" />
                        ) : null}
                      </div>
                    )}
                  </div>
                </button>
              ))}
            </div>

            {showExplanation && (
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
                <h3 className="font-semibold text-blue-900 mb-2">Объяснение:</h3>
                <p className="text-blue-800">{question.explanation}</p>
              </div>
            )}

            <div className="flex justify-between">
              <button
                onClick={() => onNavigate('details')}
                className="px-6 py-3 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors font-medium"
              >
                Изучить теорию
              </button>
              
              <div className="flex space-x-3">
                {!showExplanation && selectedAnswer !== null && (
                  <button
                    onClick={handleShowExplanation}
                    className="px-6 py-3 bg-yellow-100 text-yellow-700 rounded-lg hover:bg-yellow-200 transition-colors font-medium"
                  >
                    Показать объяснение
                  </button>
                )}
                
                <button
                  onClick={handleNextQuestion}
                  disabled={selectedAnswer === null}
                  className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors font-medium"
                >
                  {currentQuestion === quizQuestions.length - 1 ? 'Завершить' : 'Далее'}
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default QuizPage;