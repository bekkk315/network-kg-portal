import React, { useState } from 'react';
import { Play, Clock, User, Star, BookOpen, Filter, Search, Award, ExternalLink, ArrowLeft } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { Course } from '../../types';

interface CoursesPageProps {
  onNavigate: (page: string) => void;
}

const courses: Course[] = [
  {
    id: '1',
    title: 'Основы сетевых технологий',
    description: 'Комплексный курс по основам компьютерных сетей, протоколам TCP/IP, маршрутизации и коммутации. Изучите архитектуру сетей от базовых концепций до продвинутых технологий.',
    videoUrl: 'https://www.youtube.com/watch?v=NlM6JCEm3ig',
    duration: '2 часа 30 минут',
    level: 'Beginner',
    instructor: 'Бакыт Токтогулов'
  },
  {
    id: '2',
    title: 'Безопасность сетей и киберзащита',
    description: 'Углубленное изучение методов защиты сетевой инфраструктуры, настройки файрволов, VPN, системы обнаружения вторжений и современные угрозы кибербезопасности.',
    videoUrl: 'https://www.youtube.com/watch?v=jpKuabvBY8E',
    duration: '3 часа 15 минут',
    level: 'Intermediate',
    instructor: 'Айгуль Мамбетова'
  },
  {
    id: '3',
    title: 'Облачные технологии и виртуализация',
    description: 'Изучение современных облачных платформ, контейнеризации, оркестрации, микросервисной архитектуры и DevOps практик для сетевых инженеров.',
    videoUrl: 'https://www.youtube.com/watch?v=NlM6JCEm3ig',
    duration: '4 часа 45 минут',
    level: 'Advanced',
    instructor: 'Эрлан Кадыров'
  },
  {
    id: '4',
    title: 'Протоколы маршрутизации OSPF и BGP',
    description: 'Детальное изучение протоколов динамической маршрутизации, настройка OSPF и BGP, оптимизация маршрутизации в корпоративных и провайдерских сетях.',
    videoUrl: 'https://www.youtube.com/watch?v=jpKuabvBY8E',
    duration: '3 часа 20 минут',
    level: 'Advanced',
    instructor: 'Азамат Исаков'
  },
  {
    id: '5',
    title: 'Беспроводные технологии и Wi-Fi 6',
    description: 'Современные беспроводные технологии, стандарты Wi-Fi 6/6E, планирование и развертывание беспроводных сетей, решение проблем покрытия и интерференции.',
    videoUrl: 'https://www.youtube.com/watch?v=NlM6JCEm3ig',
    duration: '2 часа 55 минут',
    level: 'Intermediate',
    instructor: 'Чолпон Акматова'
  },
  {
    id: '6',
    title: 'Software-Defined Networking (SDN)',
    description: 'Программно-определяемые сети, контроллеры SDN, OpenFlow протокол, автоматизация сетевой инфраструктуры и интеграция с облачными платформами.',
    videoUrl: 'https://www.youtube.com/watch?v=jpKuabvBY8E',
    duration: '3 часа 40 минут',
    level: 'Advanced',
    instructor: 'Талант Мурзалиев'
  }
];

const CoursesPage: React.FC<CoursesPageProps> = ({ onNavigate }) => {
  const { user } = useAuth();
  const [searchTerm, setSearchTerm] = useState('');
  const [levelFilter, setLevelFilter] = useState('all');

  const filteredCourses = courses.filter(course => {
    const matchesSearch = course.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         course.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesLevel = levelFilter === 'all' || course.level === levelFilter;
    return matchesSearch && matchesLevel;
  });

  const getLevelColor = (level: string) => {
    switch (level) {
      case 'Beginner': return 'bg-green-100 text-green-800';
      case 'Intermediate': return 'bg-yellow-100 text-yellow-800';
      case 'Advanced': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getLevelLabel = (level: string) => {
    switch (level) {
      case 'Beginner': return 'Начальный';
      case 'Intermediate': return 'Средний';
      case 'Advanced': return 'Продвинутый';
      default: return level;
    }
  };

  const openYouTubeVideo = (url: string) => {
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center px-4">
        <div className="max-w-md w-full bg-white rounded-2xl shadow-xl p-8 text-center">
          <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <Play className="h-8 w-8 text-blue-600" />
          </div>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Требуется авторизация</h2>
          <p className="text-gray-600 mb-6">
            Для просмотра курсов необходимо войти в систему
          </p>
          <button
            onClick={() => onNavigate('login')}
            className="w-full bg-blue-600 text-white py-3 px-4 rounded-lg hover:bg-blue-700 transition-colors font-medium"
          >
            Войти в систему
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      {/* Back Navigation */}
      <div className="bg-white shadow-sm border-b sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <button
            onClick={() => onNavigate('home')}
            className="flex items-center text-blue-600 hover:text-blue-700 transition-colors font-medium"
          >
            <ArrowLeft className="h-5 w-5 mr-2" />
            На главную
          </button>
        </div>
      </div>

      {/* Header */}
      <section className="relative pt-16 pb-12 px-4 sm:px-6 lg:px-8 bg-gradient-to-r from-slate-900 to-blue-900">
        <div className="max-w-7xl mx-auto">
          <div className="text-center">
            <div className="flex justify-center mb-6">
              <div className="p-4 bg-gradient-to-r from-blue-500 to-indigo-600 rounded-2xl shadow-2xl">
                <Play className="h-12 w-12 text-white" />
              </div>
            </div>
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
              Облачные <span className="bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">курсы</span>
            </h1>
            <p className="text-xl text-slate-300 max-w-3xl mx-auto">
              Профессиональные видеокурсы по сетевым технологиям от ведущих экспертов Кыргызстана
            </p>
          </div>
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Search and Filters */}
        <div className="bg-white rounded-2xl shadow-lg p-6 mb-8">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
              <input
                type="text"
                placeholder="Поиск курсов..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
            <div className="flex items-center space-x-2">
              <Filter className="h-5 w-5 text-gray-400" />
              <select
                value={levelFilter}
                onChange={(e) => setLevelFilter(e.target.value)}
                className="px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="all">Все уровни</option>
                <option value="Beginner">Начальный</option>
                <option value="Intermediate">Средний</option>
                <option value="Advanced">Продвинутый</option>
              </select>
            </div>
          </div>
        </div>

        {/* Info Banner */}
        <div className="bg-gradient-to-r from-red-500 to-red-600 rounded-2xl p-6 mb-8 text-white">
          <div className="flex items-center space-x-4">
            <div className="p-3 bg-white bg-opacity-20 rounded-xl">
              <ExternalLink className="h-8 w-8" />
            </div>
            <div>
              <h3 className="text-xl font-bold mb-2">📺 Курсы на YouTube</h3>
              <p className="text-red-100">
                Все курсы размещены на YouTube для лучшего качества воспроизведения. 
                При нажатии "Смотреть курс" откроется новая вкладка с видео.
              </p>
            </div>
          </div>
        </div>

        {/* Stats */}
        <div className="grid md:grid-cols-3 gap-6 mb-12">
          <div className="bg-white rounded-xl p-6 shadow-lg">
            <div className="flex items-center">
              <div className="p-3 bg-blue-100 rounded-lg">
                <BookOpen className="h-6 w-6 text-blue-600" />
              </div>
              <div className="ml-4">
                <p className="text-2xl font-bold text-gray-900">{courses.length}</p>
                <p className="text-gray-600">Доступных курсов</p>
              </div>
            </div>
          </div>
          <div className="bg-white rounded-xl p-6 shadow-lg">
            <div className="flex items-center">
              <div className="p-3 bg-green-100 rounded-lg">
                <Clock className="h-6 w-6 text-green-600" />
              </div>
              <div className="ml-4">
                <p className="text-2xl font-bold text-gray-900">20+</p>
                <p className="text-gray-600">Часов контента</p>
              </div>
            </div>
          </div>
          <div className="bg-white rounded-xl p-6 shadow-lg">
            <div className="flex items-center">
              <div className="p-3 bg-purple-100 rounded-lg">
                <Award className="h-6 w-6 text-purple-600" />
              </div>
              <div className="ml-4">
                <p className="text-2xl font-bold text-gray-900">6</p>
                <p className="text-gray-600">Кыргызских экспертов</p>
              </div>
            </div>
          </div>
        </div>

        {/* Courses Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredCourses.map((course) => (
            <div
              key={course.id}
              className="bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1"
            >
              <div className="relative group cursor-pointer" onClick={() => openYouTubeVideo(course.videoUrl)}>
                <div className="aspect-video bg-gradient-to-br from-red-500 to-red-600 flex items-center justify-center">
                  <div className="text-center text-white">
                    <Play className="h-16 w-16 mx-auto mb-2 group-hover:scale-110 transition-transform duration-300" />
                    <p className="text-sm font-medium opacity-90">Нажмите для просмотра</p>
                  </div>
                </div>
                <div className="absolute top-4 left-4">
                  <span className={`px-3 py-1 rounded-full text-xs font-medium ${getLevelColor(course.level)}`}>
                    {getLevelLabel(course.level)}
                  </span>
                </div>
                <div className="absolute top-4 right-4">
                  <div className="bg-red-600 text-white px-2 py-1 rounded text-xs font-medium flex items-center">
                    <ExternalLink className="h-3 w-3 mr-1" />
                    YouTube
                  </div>
                </div>
                <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-20 transition-all duration-300 flex items-center justify-center">
                  <div className="transform scale-0 group-hover:scale-100 transition-transform duration-300">
                    <div className="bg-white bg-opacity-20 rounded-full p-4">
                      <Play className="h-8 w-8 text-white" />
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="p-6">
                <h3 className="text-xl font-semibold text-gray-900 mb-3 leading-tight">
                  {course.title}
                </h3>
                
                <p className="text-gray-600 text-sm mb-4 leading-relaxed line-clamp-3">
                  {course.description}
                </p>
                
                <div className="flex items-center justify-between text-sm text-gray-500 mb-4">
                  <div className="flex items-center">
                    <Clock className="h-4 w-4 mr-1" />
                    {course.duration}
                  </div>
                  <div className="flex items-center">
                    <User className="h-4 w-4 mr-1" />
                    {course.instructor}
                  </div>
                </div>
                
                <button
                  onClick={() => openYouTubeVideo(course.videoUrl)}
                  className="w-full bg-red-600 text-white py-3 px-4 rounded-lg hover:bg-red-700 transition-colors font-medium flex items-center justify-center group"
                >
                  <Play className="h-4 w-4 mr-2 group-hover:scale-110 transition-transform" />
                  Смотреть курс
                  <ExternalLink className="h-4 w-4 ml-2" />
                </button>
              </div>
            </div>
          ))}
        </div>

        {filteredCourses.length === 0 && (
          <div className="text-center py-12">
            <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Search className="h-8 w-8 text-gray-400" />
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-2">Курсы не найдены</h3>
            <p className="text-gray-600">Попробуйте изменить поисковый запрос или фильтры</p>
          </div>
        )}
      </div>

      <style jsx>{`
        .line-clamp-3 {
          display: -webkit-box;
          -webkit-line-clamp: 3;
          -webkit-box-orient: vertical;
          overflow: hidden;
        }
      `}</style>
    </div>
  );
};

export default CoursesPage;